=== Estacion FCh ===
Contributors: marredondo
Tags: solaratacama, solar, energia, fundacion, chile
Requires at least: 1.2.2
Tested up to: 1.2.2
Stable tag: 1.2.2
License: GPLv3

== Description ==

== Installation ==

== Changelog ==

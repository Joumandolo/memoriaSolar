=== Estacion FCh ===
Contributors: marredondo
Tags: solaratacama, solar, energia, fundacion, chile
Requires at least: 1.2.2
Tested up to: 1.2.4
Stable tag: 1.2.5
License: GPLv3

== Description ==

== Installation ==

== Changelog ==

06-11-2012: cambio de campo de ghi de la base de datos  ghiwm2 -> ghi2wm2

<?php
/*
Plugin Name: Estacion Solar Fch
Plugin URI: http://www.solaratacama.cl
Description: Muestra informacion capturada mediante estaciones de medicion solar de la redSolLac
Version: 0.9
Author: Manuel Arredondo
Author URI:
*/

// Cuando se inicializa el widget llamaremos al metodo register de la clase Widget_ultimosPostPorAutor
add_action( "widgets_init", array( "Widget_solarMeteo", "register" ) );

// Clase Widget_ultimosPostPorAutor
class Widget_solarMeteo {

	// Panel de control que se mostrara abajo de nuestro Widget en el panel de configuración de Widgets
	function control() {
	        echo "Hola, soy el panel de control.";
	        }

	// Metodo que se llamara cuando se visualize el Widget en pantalla
	function widget($args) {
	        echo $args["before_widget"];
	        echo'
	                <div id="ghi" style="width:200px;height:100px"></div>
	                <script type="text/javascript">
	                        jQuery.ajax({
	                                url: "wp-content/plugins/solarFch/ghi.php",
	                                type: "POST",
	                                dataType: "html",
	                                async: false,
	                                success: function(data, textStatus, jqXHR){
	                                        jQuery("#ghi").append(data);
	                                        },
	                                });
	                </script>';
	        echo $args["after_widget"];
		}

	// Meotodo que se llamara cuando se inicialice el Widget
	function register() {
	        // Incluimos el widget en el panel control de Widgets
	        register_sidebar_widget( "Radiacion Solar", array( "Widget_solarMeteo", "widget" ) );
	        // Formulario para editar las propiedades de nuestro Widget
	        register_widget_control( "Raciacion Solar", array( "Widget_solarMeteo", "control" ) );
	        }
	}
?>

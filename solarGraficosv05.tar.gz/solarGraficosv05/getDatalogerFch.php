<?php
/* Obtenemos los datos provenientes por get desde el dataloger*/
$dataloger = array(
        "battV" => $_GET["battV"],
        "radW" => $_GET["radW"],
        "radMj" => $_GET["radMj"],
        "radW2" => $_GET["radW2"],
        "radMj2" => $_GET["radMj2"],
        "airTc" => $_GET["airTc"],
        "rh" => $_GET["rh"]
        );

/* Conectarse a la base de datos */
$conexion = mysql_connect("localhost", "root", ".joumandolo") or die("no conexion");
mysql_select_db("wordpress", $conexion) or die("no bd");

/* insertar registros */
$q = "INSERT INTO solarDatos2 (Rad_W, Rad_kJ_Tot, rh, Temp_TC, BattV) VALUES ($dataloger['radW'],$dataloger['radMj'],$dataloger['rh'],$dataloger['airTc'],$dataloger['battV'])";

$r = mysql_query($q, $conexion) or die(mysql_error());

//var_dump($dataloger);

//header('Content-type: application/json');
//$datos = json_encode($datos);
//echo $datos;


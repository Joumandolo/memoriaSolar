<?php
var_dump($_POST);
//echo $_POST['datosJson']; 
?>

=== Calculadora Solar ===
Contributors: marredondo
Tags: solaratacama, solar, energia, fundacion, chile
Requires at least: 1.0.
Tested up to: 1.0.
Stable tag: 1.0.
License: GPLv3

== Description ==

== Installation ==

== Changelog ==
primera version estable

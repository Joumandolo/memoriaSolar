<?php $url = $_POST["siteUrl"]."/wp-content/plugins/solarCalc/" ?>
<?php //$url = "http://".$_SERVER["SERVER_NAME"]."/wordpress/wp-content/plugins/solarCalc/" ?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script language="javascript" type="text/javascript" src="<?echo $url;?>libs/jquery-ui/js/jquery-1.7.2.min.js"></script>
<script language="javascript" type="text/javascript" src="<?echo $url;?>libs/jquery-ui/js/jquery-ui-1.8.21.custom.min.js"></script>
<script language="javascript" type="text/javascript" src="<?echo $url;?>libs/flot/jquery.flot.js"></script>
<script language="javascript" type="text/javascript" src="<?echo $url;?>libs/dateFormat.js"></script>

<link href="<?echo $url;?>libs/jquery-ui/css/ui-darkness/jquery-ui-1.8.21.custom.css" rel="stylesheet" type="text/css"/>
<link href="<?echo $url;?>solar.css" rel="stylesheet" type="text/css"/>
<!--[if IE]><script language="javascript" type="text/javascript" src="<?echo $url;?>libs/flot/excanvas.js"></script><![endif]-->

<div id="calculadora">
	<div id="ubicacion">
		<div id="imagen"></div>
		<div id="cabeza">
			<label id="titulo">Ubicación Geográfica</label>
		</div>
		<div id="cuerpo">
			<label>País:</label><select id='pais'></select>
			<label>Región:</label><select id='region'></select>
			<label>Comuna:</label><select id='comuna'></select>
			<label>Latitud:</label><input type="text" id='latitud' disabled></input>
			<label>Longitud:</label><input type="text" id='longitud' disabled></input>
		</div>
	</div>

	<div id="resultado">	
		<div id="cabeza"> 
			<label id="titulo">Resultados</label>
		</div>
		<div id="cuerpo"></div>
	</div>

	<div id="planta">
		<div id="imagen"></div>
		<div id="cabeza">
			<label id="titulo">Especificaciones del sistema PV</label>
		</div>
		<div id="cuerpo">
			<label id='potenciap'>Potencia planta[W]:</label><input id='potenciap' value="4000"/>
			<label id='factorp'>Factor de planta:</label><input id='factorp' value="0.77"/><br><hr>
			<label id='orientacion'>Orientación[°]:</label><input id='orientacion' value="0"/>
			<label 	id ='inclinacion'>Inclinación[°]:</label><input id='inclinacion' value="0"/>
			<label id='albedo'>Albedo:</label><input id='albedo' value="0.2"/>
		</div>
	</div>

	<div id="energia" >
		<div id="imagen"></div>
		<div id="cabeza">
			<label id="titulo">Información de energía</label>
		</div>
		<div id="cuerpo">
			<label id='cenergia'>Costo de la electricidad(moneda local)[$/kWh]:</label>
			<input id='cenergia'></input>
		</div>
	</div>

	<div id="boton">
		<a id="calcular"></a>
		<label id="calcular">Calcular</label>
	</div>
</div>

<script type="text/javascript">
var datos;
var paises = {};
var ciudades = {};
var comunas = {};
var etiquetaDatos = {};
var datosConsumo = [];

/*Calcular*/
jQuery("#calcular").bind("click", function(event){
	//event.preventDefault();
	etiquetaDatos.comuna = jQuery("#comuna").val();
	etiquetaDatos.ori = jQuery("#orientacion").val();
	etiquetaDatos.incl = jQuery("#inclinacion").val();
	etiquetaDatos.alb = jQuery("#albedo").val();
	etiquetaDatos.pnp = jQuery("input#potenciap").val();
	etiquetaDatos.fp = jQuery("input#factorp").val();
	etiquetaDatos.vkwh = jQuery("input#cenergia").val();
	jQuery.ajax({
		url:'<?echo $url;?>radiacioHorizontalHoraria.php',
		type:'POST',async:true,data:etiquetaDatos,dataType:'html',
		beforeSend:function(){
			// this is where we append a loading image
			jQuery("div#resultado div#cuerpo").html("");
			jQuery("div#resultado div#cuerpo").append('<div id="load"><img src="<?echo $url;?>img/ajax-loader.gif" alt="Loading..." /></div>');
			jQuery(this).delay(10000);
		},
		success: function(data, textStatus, jqXHR){
			jQuery("div#resultado div#cuerpo").html("");
			jQuery("div#resultado div#cuerpo").append(data);
		}
	});
	etiquetaDatos = {};
});

/* Poblar paises  */
jQuery(document).ready(function(){
	etiquetaDatos.etiqueta = "ubicacion";
	etiquetaDatos.campoDestino = "pais";
	//etiquetaDatos.campoFuente = "pais";
	//etiquetaDatos.where = "V Región de Valparaíso";
	jQuery.ajax({
		url:'<?echo $url;?>solarDatos.php',
		type:'POST',async:false,data:etiquetaDatos,dataType:'json',
		success: function(data, textStatus, jqXHR){
			data = data["options"];
			//console.log(data);
			var options = '<option value=0>Seleccion una pais...</option>';
			for (var i = 0; i < data.length; i++) {
				options += '<option value="' + data[i] + '">' + data[i] + '</option>';
			}
		jQuery("select#pais").html(options);
		//$("#resultado").html(data);
		}
	});
	//etiquetaDatos = {};
});

/* Poblar ciudades */
jQuery("select#pais").bind("change", function(event){
	etiquetaDatos.etiqueta = "ubicacion";
	etiquetaDatos.campoFuente = "pais";
        etiquetaDatos.where = event.target.value;
        etiquetaDatos.campoDestino = "region";
	//console.log(etiquetaDatos);

	if(etiquetaDatos.where != "0"){
		jQuery.ajax({
			url:'<?echo $url;?>solarDatos.php',
			type:'POST',async:false,data:etiquetaDatos,dataType:'json',
			success: function(data, textStatus, jqXHR){
				data = data["options"];
				console.log(textStatus);
				var options = '<option value=0>Seleccion una ...</option>';
				for (var i = 0; i < data.length; i++) {
					options += '<option value="' + data[i] + '">' + data[i] + '</option>';
				}
				jQuery("select#region").html(options);
				var options = '<option value=0>Seleccion una comuna...</option>';
				jQuery("select#comuna").html(options);
				jQuery("input#latitud").empty();
				jQuery("input#longitud").empty();
				//$("#resultado").empty();
			}
		});
	}else{
		var options = '<option value=0>Región...</option>';
		jQuery("select#region").html(options);
		var options = '<option value=0>Comuna...</option>';
                jQuery("select#comuna").html(options);
		jQuery("input#latitud").empty();
                jQuery("input#longitud").empty();
	}
});

/* Poblar comunas */
jQuery("select#region").bind("change", function(event){
	etiquetaDatos.etiqueta = "ubicacion";
	etiquetaDatos.campoFuente = "region";
	etiquetaDatos.where = event.target.value;
	etiquetaDatos.campoDestino = "comuna";
	console.log(etiquetaDatos);

	if(etiquetaDatos.where != "0"){
		jQuery.ajax({
			url:'<?echo $url;?>solarDatos.php',
			type:'POST',async:false,data:etiquetaDatos,dataType:'json',
			success: function(data, textStatus, jqXHR){
				data = data["options"];
				console.log(data);
				var options = '<option value=0>Comuna...</option>';
				for (var i = 0; i < data.length; i++) {
					options += '<option value="' + data[i] + '">' + data[i] + '</option>';
				}
				jQuery("select#"+etiquetaDatos.campoDestino).html(options);
				jQuery("input#latitud").empty();
				jQuery("input#longitud").empty();
			}
		});
	}else{
		var options = '<option value=0>Comuna...</option>';
		jQuery("select#comuna").html(options);
		jQuery("input#latitud").empty();
                jQuery("input#longitud").empty();
	}
	//etiquetaDatos = {};
});

/* Mostrar coordenadas */
jQuery("select#comuna").bind("change", function(event){
	etiquetaDatos.etiqueta = "ubicacion";
	etiquetaDatos.campoFuente = "comuna";
	etiquetaDatos.where = event.target.value;
	etiquetaDatos.campoDestino = "latitud, longitud"

	if(etiquetaDatos.where != "0"){
		jQuery.ajax({
			url:'<?echo $url;?>solarDatos.php',
			type:'POST',async:true,data:etiquetaDatos,dataType:'json',
			success: function(data, textStatus, jqXHR){
				data = data["options"];
				//console.log(data);
				jQuery("input#latitud").val(parseFloat(data[0][0]).toFixed(2));
				jQuery("input#longitud").val(parseFloat(data[0][1]).toFixed(2));
				}
			});
	}else{
		jQuery("input#latitud").empty();
                jQuery("input#longitud").empty();
	}
	etiquetaDatos = {};
});

/* Graficar Perfiles */
etiquetaDatos.etiqueta = "perfil";
jQuery.ajax({
	url:'<?echo $url;?>solarDatos.php',
	type:'POST',async:true,data:etiquetaDatos,dataType:'json',
	success: function(data, textStatus, jqXHR){
		datosConsumo = data["options"];
		//console.log(datosConsumo);
		var options = '<option value=0>Seleccione un perfil de consumo...</option>';
		for (var i = 0; i < datosConsumo.length; i++) {
			options += '<option value="' + datosConsumo[i]["label"] + '">' + datosConsumo[i]["label"] + '</option>';
		}
		jQuery("select#optconsumo").html(options);
	}
});
etiquetaDatos = {};

/*Crear la grafica*/
jQuery("select#optconsumo").bind("change", function(event){
	var a = event.target.value;
	var data = [];
	jQuery.each(datosConsumo, function(key, val){ if(val.label == a) { data.push(val); } });
	//console.log(data);
	var placeholder = jQuery("div#graficoConsumo");
	var options = {
		series: { bars: { show: true, barWidth: 0.6, align: "center" }},
		legend: { show: false, noColumns: 1, margin: 2},
		xaxis:  { ticks: 24, minTickSize: 1, tickDecimals:0 },
	};
	var plot = jQuery.plot(placeholder, data, options);

});

/* Mostrar div de fijaciones */
jQuery("select#fijacion").bind("change", function(event){
	if(event.target.value == "fija"){
		jQuery("div#planta").append("<div id='fija'><label>Inclinacion:</label><input id='inclinacion'></input><br><label>Azimuth:</label><input id='azimuth'></input></div>");
		jQuery("div#planta").css("height","280px");
		jQuery("div#fija").css({'position':"absolute","top":"150","left":"20","width":"180px","height":"100px","border":"3px black solid"});
	}else{
		jQuery("div#fija").remove();
		jQuery("div#planta").css("height","150px");
	}
	
});

</script>
</body>
</html>

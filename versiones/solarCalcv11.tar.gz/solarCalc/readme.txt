=== Calculadora Solar ===
Contributors: marredondo
Tags: solaratacama, solar, energia, fundacion, chile
Requires at least: 1.0.
Tested up to: 1.1.
Stable tag: 1.0.
License: GPLv3

== Description ==

== Installation ==

== Changelog ==
adaptaciones para worpress

primera version estable

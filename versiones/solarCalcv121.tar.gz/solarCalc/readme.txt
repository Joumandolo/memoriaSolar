=== Calculadora Solar ===
Contributors: marredondo
Tags: solaratacama, solar, energia, fundacion, chile
Requires at least: 1.0.
Tested up to: 1.2.1
Stable tag: 1.1.
License: GPLv3

== Description ==

== Installation ==

== Changelog ==
v1.2.1
arreglo visual en graficos, sello de agua
correccion de la suma anual  deradiacion m2

v1.2
se agregan los graficos
correccion de la variable que toma los datos de inclinacion

v1.1
adaptaciones para worpress

v.1.0
primera version estable

<?php
/*
Plugin Name: Estacion Solar Fch
Plugin URI: http://www.solaratacama.cl
Description: Muestra informacion capturada mediante estaciones de medicion solar de la redSolLac; Compatible con Chrome 19, IE 9, Firefox 12.
Version: 1.0.1
Author: Manuel Arredondo
Author URI: http://wp.mnj.cl/
License: GPL v3.0
*/

/* Agregar opcion al inicializar el plugin */
//add_action( "widgets_init", array( "solarFch", "iniciar" ) );
add_action( "init", array( "solarFch", "iniciar") );
register_activation_hook(__FILE__, array('solarFch','crearPagina') ); 
register_deactivation_hook(__FILE__, array('solarFch', 'eliminarPagina') );

// Clase Widget_ultimosPostPorAutor
class solarFch {
	/* Crear pagina  */
	function crearPagina(){
		$page_title = "Estacion Solar Fch";
		$pagina = get_page_by_title( $page_title );
		if( !$pagina->ID ){
			/* si no existe crear pagina nueva */
			$paginaId = wp_insert_post( self::post( $page_title ), $wp_error );
			update_post_meta( $paginaId, "_wp_page_template", "page-full.php" );
		}else{
			wp_delete_post( $page->ID );
			$paginaId = wp_insert_post( self::post( $page_title ), $wp_error );
			update_post_meta( $paginaId, "_wp_page_template", "page-full.php" );
		}
	}

	function eliminarPagina(){
		$page_title = "Estacion Solar Fch";
		/* si la pagina existe eliminar */
		$page = get_page_by_title( $page_title );
		if( $page->ID ) { wp_delete_post( $page->ID ); }
	}

	/* Contenido de la pagina */
	private static function contenido(){
		/* añadimos contenedores */
		$c = '
			<div id="estacionfch" style="width:840px;height:360px"></div>
			<script type="text/javascript">
				jQuery.ajax({
        				url: "wp-content/plugins/solarFch/graficoWp.php",
        				type: "POST",
        				dataType: "html",
        				async: false,
        				success: function(data, textStatus, jqXHR){
        					jQuery("#estacionfch").append(data);
					},
				});
			</script>';
		return $c;
	}

	/* Estructura de la pagina */
	private static function post($p){
		$post = array(
			'menu_order' => 1,
			'post_author' => 5,
			'post_content' => self::contenido(),
			'post_excerpt' => "Nueva herramienta para visualizar los datos obtenidos mediante las estaciones meteorologicas solares.",
			'post_date' => date("Y-m-d H:i:s"),
			'post_status' => 'publish', 
			'post_title' => $p,
			'post_type' => 'page',
			'post_parent' => 3,
			'comment_status' => 'closed',
			'post_category' => array(2)
			);  
		return $post;
	}

	/* Panel de control ghi */
	function ghiControl() {
	        echo "No hay opciones disponibles.";
	        }
	/* Visualizar Widget ghi */
	function ghi($args) {
	        echo $args["before_widget"];
	        echo'
	                <div id="ghi" style="width:200px;height:100px"></div>
	                <script type="text/javascript">
	                        jQuery.ajax({
	                                url: "wp-content/plugins/solarFch/ghi.php",
	                                type: "POST",
	                                dataType: "html",
	                                async: false,
	                                success: function(data, textStatus, jqXHR){
	                                        jQuery("#ghi").append(data);
	                                        },
	                                });
	                </script>';
	        echo $args["after_widget"];
		}
	/* Panel de control hr */
        function hrControl() {
                echo "No hay opciones disponibles.";
                }
        /* Visualizar Widget hr */
        function hr($args) {
                echo $args["before_widget"];
                echo'
                        <div id="hr" style="width:200px;height:100px"></div>
                        <script type="text/javascript">
                                jQuery.ajax({
                                        url: "wp-content/plugins/solarFch/hr.php",
                                        type: "POST",
                                        dataType: "html",
                                        async: false,
                                        success: function(data, textStatus, jqXHR){
                                                jQuery("#hr").append(data);
                                                },
                                        });
                        </script>';
                echo $args["after_widget"];
                }
	
	/* Panel de control ta */
        function taControl() {
                echo "No hay opciones disponibles.";
                }
        /* Visualizar Widget ta */
        function ta($args) {
                echo $args["before_widget"];
                echo'
                        <div id="ta" style="width:200px;height:100px"></div>
                        <script type="text/javascript">
                                jQuery.ajax({
                                        url: "wp-content/plugins/solarFch/ta.php",
                                        type: "POST",
                                        dataType: "html",
                                        async: false,
                                        success: function(data, textStatus, jqXHR){
                                                jQuery("#ta").append(data);
                                                },
                                        });
                        </script>';
                echo $args["after_widget"];
                }
	/* Meotodo que se llamara cuando se inicialice el Widget */
	function iniciar() {
		/* Iniciar Pagina */
		//register_activation_hook(__FILE__, 'crearPagina' ); 
		//register_deactivation_hook(__FILE__, 'eliminarPagina' );
	        /* Incluimos el widget en el panel control de Widgets */
	        register_sidebar_widget( "Radiacion Solar GHI", array( "solarFch", "ghi" ) );
	        register_sidebar_widget( "Radiacion Solar HR", array( "solarFch", "hr" ) );
	        register_sidebar_widget( "Radiacion Solar TA", array( "solarFch", "ta" ) );
	        /* Formulario para editar las propiedades de nuestro Widget */
	        register_widget_control( "Raciacion Solar GHI", array( "solarFch", "ghiControl" ) );
	        register_widget_control( "Raciacion Solar HR", array( "solarFch", "hrControl" ) );
	        register_widget_control( "Raciacion Solar TA", array( "solarFch", "taControl" ) );
	        }
	}
?>
